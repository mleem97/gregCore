# Changelog

## [0.1.0] - 2026-04-18

### Added
- Initiale Version des gregCore Frameworks
- Unterstützung für GregHookBus, Services und Registries
- NuGet-Paketstruktur inkl. Multi-Target, Symbol-Paket und GitHub Actions CI/CD

### Changed
- Aktualisierung der Projektstruktur für bessere Modularität

### Removed
- Keine Funktionen entfernt in dieser Version